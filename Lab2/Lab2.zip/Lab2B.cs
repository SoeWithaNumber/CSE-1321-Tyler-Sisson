using System;
/*
Class: CSE 1321L
Term: 1
Instructor: Meghana Bandaru
Name: Tyler Sisson
Lab: C#
*/

class Lab2A
{
    public static void Main(string[] args)
    {
        Console.WriteLine("___*___");
        Console.WriteLine("__*_*__");
        Console.WriteLine("_*_*_*_");
        Console.WriteLine("*_*_*_*");
        Console.WriteLine("_*_*_*_");
        Console.WriteLine("__*_*__");
        Console.WriteLine("___*___");

    }
}